<?php define('HOST','localhost'); define('USER','root');
define('PASS','');
define('DB','nama_database'); //Sesuaikan dengan nama database

$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>
