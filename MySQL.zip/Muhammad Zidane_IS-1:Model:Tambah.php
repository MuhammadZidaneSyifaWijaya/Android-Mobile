<?php if($_SERVER['REQUEST_METHOD']=='POST'){
$name = $_POST['name'];
$number = $_POST['number'];

$sql = "INSERT INTO contact (name,number) VALUES ('$name','$number')"; require_once('koneksi.php');

if(mysqli_query($con,$sql)){
echo 'Berhasil Menambahkan Contact';
 
}else{

}
 

echo 'Gagal Menambahkan Contact';
 

mysqli_close($con);
}
?>

