<?php require_once('koneksi.php');
$id	= $_GET['id'];
$sql	= "DELETE FROM contact WHERE id=$id;";

if(mysqli_query($con,$sql)){
echo 'Berhasil Menghapus Contact';
 
}else{

}
 

echo 'Gagal Menghapus Contact';
 

mysqli_close($con);
?>
