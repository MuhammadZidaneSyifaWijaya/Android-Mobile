<?php if($_SERVER['REQUEST_METHOD']=='POST'){
$id	= $_POST['id'];
$name = $_POST['name'];
$number = $_POST['number']; require_once('koneksi.php');
$sql = "UPDATE contact SET name = '$name', number = '$number' WHERE id =
$id;";

if(mysqli_query($con,$sql)){
echo 'Berhasil Mengubah Contact';
 
}else{

}
 

echo 'Gagal Mengubah Contact';
 

mysqli_close($con);
}
?>
