package com.example.muhammadzidanesyifawijaya.userinputcontrol;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView; import android.widget.ArrayAdapter; import android.widget.EditText; import android.widget.CheckBox; import android.widget.RadioGroup;

import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {
    // Define TAG for logging.
    private static final String TAG = MainActivity.class.getSimpleName();
    // Define mSpinnerLabel for the label (the spinner item that the user chooses).
    private String mSpinnerLabel = "";

    /**
     *	Set the content view, create the spinner, and create the array adapter for the spinner.
     *	@param savedInstanceState	Saved instance.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main);

// Create the spinner.
        Spinner spinner = (Spinner) findViewById(R.id.label_spinner);
        if (spinner != null) { spinner.setOnItemSelectedListener(this);
        }

// Create ArrayAdapter using the string array and default spinner layout.
        ArrayAdapter<CharSequence> adapter;
        adapter = ArrayAdapter.createFromResource(this, R.array.labels_array, android.R.layout.simple_spinner_item);

// Specify the layout to use when the list of choices appears.
        adapter.setDropDownViewResource (android.R.layout.simple_spinner_dropdown_item);

// Apply the adapter to the spinner.
        if (spinner != null) { spinner.setAdapter(adapter);
        }

    }

    /**
     *	Retrieves the text and spinner item and shows them in text_phonelabel.
     *	@param view	The view containing editText_phone.
     */
    public void showText(View view) {
        EditText etName		= (EditText) findViewById(R.id.editText_name); EditText etPhone		= (EditText) findViewById(R.id.editText_phone); CheckBox cbFamily	= (CheckBox)findViewById(R.id.cb_family); CheckBox cbFriends = (CheckBox)findViewById(R.id.cb_friends); RadioGroup rgSim		= (RadioGroup)findViewById(R.id.rgSim);

        if ((etName != null) && (etPhone != null)) { StringBuffer group = new StringBuffer();
            if (cbFamily.isChecked()) { group.append("Family "); }
            if (cbFriends.isChecked()) { group.append("Friends"); }

            String sim = new String();
            int checkedRadioButtonId = rgSim.getCheckedRadioButtonId();
            if (checkedRadioButtonId == R.id.rg1) {
                sim = "SIM 1";
            } else if (checkedRadioButtonId == R.id.rg2) {
                sim = "SIM 2";
            }
                    String showString = (etName.getText().toString() + " - " + etPhone.getText().toString() + " - " + group.toString() + " - " +
                    sim + " - " +
                    mSpinnerLabel);
// Assign to phoneNumberResult the view for text_phonelabel to prepare

            TextView phoneNumberResult = (TextView)

                    findViewById(R.id.text_phonelabel);
// Show the showString in the phoneNumberResult.
            if (phoneNumberResult != null) phoneNumberResult.setText(showString);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long
            id) {
        mSpinnerLabel = adapterView.getItemAtPosition(pos).toString();
//showText(view);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { Log.i(TAG, getString(R.string.nothing_selected));
    }
}
