package com.example.muhammadzidanesyifawijaya.uts_muhammadzidanesyifawijaya_10521002_userinputcontrol;

import android.Manifest;
import android.content.ContentProvider;
import android.content.ContentProviderOperation;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView; import android.widget.ArrayAdapter; import android.widget.EditText; import android.widget.CheckBox; import android.widget.RadioGroup;

import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {

    private String mSpinnerLabel = "";

    /**
     *	Set the content view, create the spinner, and create the array adapter for the spinner.
     *	@param savedInstanceState	Saved instance.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_CONTACTS},
                PackageManager.PERMISSION_GRANTED);


        Spinner spinner = (Spinner) findViewById(R.id.label_spinner);
        if (spinner != null) {
            spinner.setOnItemSelectedListener(this);
        }

    }
    public void buttonAddContact_Onclick(View view) {

        Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
        intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);

        EditText mFirstname= (EditText) findViewById(R.id.txtFirstname);
        EditText mFamilyname= (EditText) findViewById(R.id.txtFamilyName);
        EditText Phone =(EditText) findViewById(R.id.Phonenumber);
        CheckBox cbFamily	= (CheckBox)findViewById(R.id.cb_family);
        CheckBox cbFriends = (CheckBox)findViewById(R.id.cb_friends);
        RadioGroup rgSim		= (RadioGroup)findViewById(R.id.rgSim);

        intent.putExtra(ContactsContract.Intents.Insert.PHONE, Phone.getText())
                .putExtra(ContactsContract.Intents.Insert.PHONE_TYPE,
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .putExtra(ContactsContract.Intents.Insert.NAME, mFirstname.getText() + "" + mFamilyname.getText());

        if ((mFamilyname != null) && (Phone != null)) {
            StringBuffer group = new StringBuffer();
            if (cbFamily.isChecked()) {
                group.append("Family ");
            }
            if (cbFriends.isChecked()) {
                group.append("Friends");
            }
// Create ArrayAdapter using the string array and default spinner layout.
            ArrayAdapter<CharSequence> adapter;
            adapter = ArrayAdapter.createFromResource(this, R.array.labels_array, android.R.layout.simple_spinner_item);
            ArrayList<ContentProviderOperation> contentProviderOperations = new ArrayList<ContentProviderOperation>();


            contentProviderOperations.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build());

            //adding Name
            contentProviderOperations.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValueBackReference(ContactsContract.Data.MIMETYPE, Integer.parseInt(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE))
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, mFamilyname.getText().toString()).build());
            //adding phone number
            contentProviderOperations.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValueBackReference(ContactsContract.Data.MIMETYPE, Integer.parseInt(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE))
                    .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, Phone.getText().toString()).build());


        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
